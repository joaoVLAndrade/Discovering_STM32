/*
 * app.h
 *
 *  Created on: Mar 15, 2022
 *      Author: João
 */

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_led_control(void);
void app_loop(void);
void app_led_turn_off(void);

#endif /* APP_H_ */
