/*
 * app.h
 *
 *  Created on: Nov 15, 2020
 *      Author: marce
 */

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_loop(void);
void app_tick_1ms(void);
void app_switch_interrupt(void);

#endif /* APP_H_ */
