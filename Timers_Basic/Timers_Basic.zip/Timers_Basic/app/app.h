/*
 * app.h
 *
 *  Created on: Mar 2, 2022
 *      Author: João
 */

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_loop(void);
void app_switch_0_interrupt(void);
void app_change_led_blink_time(void);

#endif /* APP_H_ */
