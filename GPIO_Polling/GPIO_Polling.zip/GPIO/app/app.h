/*
 * app.h
 *
 *  Created on: Feb 12, 2022
 *      Author: João
 */

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_loop(void);



#endif /* APP_H_ */
