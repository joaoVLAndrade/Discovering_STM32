/*
 * shell.h
 *
 *  Created on: Nov 15, 2020
 *      Author: marce
 */

#ifndef SHELL_H_
#define SHELL_H_

void shell_init(void);
extern void shell_tick_1ms(void);

#endif /* SHELL_H_ */
